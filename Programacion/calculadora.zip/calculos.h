

int menu();

void suma();

void resta();

void multi();

void div();

void poten();

void raiz();

void facto();
